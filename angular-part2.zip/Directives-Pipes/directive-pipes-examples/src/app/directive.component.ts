import { Component, OnInit } from '@angular/core';
 
import { ColorDirective } from './double-div.directive';
import { ConditionalViewDirective } from './image-div.directive';
import {FormsModule} from '@angular/forms'; // <--- JavaScript import 
//The FormsModule for using NgModel directive

@Component({
  selector: 'app-root',
  standalone: true,
  imports:[ColorDirective,ConditionalViewDirective,
    FormsModule] ,
  templateUrl: './directive.component.html',
  
})
export class DirectivePage {
    value = 'green'  
    condition = false; 
    flag = false;
     name = "Nanan"
    toggleCondition(){
        /* let flag =  /^\s*(true|1|on)\s*$/i.test(this.condition);
         if(flag) 
            { 
                console.log('condition is true')
               // this.condition = "false";
                flag = false
            }
        else
        {
            console.log('condition is false')
           // this.condition = "true";
            flag = true
        } */
       }

}
