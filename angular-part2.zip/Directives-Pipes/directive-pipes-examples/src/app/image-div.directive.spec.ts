import { ImageDivDirective } from './image-div.directive';

describe('ImageDivDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageDivDirective();
    expect(directive).toBeTruthy();
  });
});
