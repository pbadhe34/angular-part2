import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[update]',
  standalone: true
})
export class ColorDirective implements OnInit 
{
      
  
//Render with default color value and not by 
//The value set from owner element
 

/*ElementRef is simply like 
document.getElementById('myId'); 
//used to access basic native element present in DOM.
nativeElement:use this as the last resort when 
direct access to DOM is needed. 

TmplateRef is used to access DOM element within
template.
Structural directive uses this TemplateRef.

 */
   @Input() update = '';
  constructor(private el: ElementRef) {      
    console.log("Set with default value "+this.update)
    this.el.nativeElement.style. backgroundColor 
    = this.update  

     

  }  
    
    @Input() color = '';   
  ngOnInit(): void {
    console.log("set in ngOnInit() with color as " +this.color)  
    this.el.nativeElement.style. backgroundColor
    = this.update||this.color   
  } 

 
  /* @Input() // specify Input setter method
  set textcolor(textcolor: string) {
    console.log("Input Value set in setter()")
    this.textcolor =  textcolor  
  }   */

  /* get tcolor(): string {
    console.log("Return the color with getter()")
    return this.textcolor;
  } */
   

}
