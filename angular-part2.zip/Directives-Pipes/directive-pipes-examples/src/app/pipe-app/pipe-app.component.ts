import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UpperCasePipe } from '../upper-case.pipe';
import { SquarePipe } from '../math-square-pipe';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule,CommonModule,UpperCasePipe,SquarePipe],
  templateUrl: './pipe-app.component.html',
  styleUrl: './pipe-app.component.css'
})
export class PipeAppComponent {
  myDate = Date.now(); 
  userName = "ashok wankhede"
  num = 12345678
   
}
