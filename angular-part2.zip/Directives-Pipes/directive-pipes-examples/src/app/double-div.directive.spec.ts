import { DoubleDivDirective } from './double-div.directive';

describe('DoubleDivDirective', () => {
  it('should create an instance', () => {
    const directive = new DoubleDivDirective();
    expect(directive).toBeTruthy();
  });
});
