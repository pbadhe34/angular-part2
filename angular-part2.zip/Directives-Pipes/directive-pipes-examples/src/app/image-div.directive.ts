import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[view]',
  standalone: true
})

/* The Structural Directive creates an embedded view 
from the Angular-generated <ng-template> 
and inserts that view in a view container 
adjacent to the directive's original <p> host element.

TemplateRef helps to get to the <ng-template>
contents and ViewContainerRef accesses 
the view container.
 */
export class ConditionalViewDirective {
  private hasView = false;

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
  ) {}

  @Input() 
  set view(condition: boolean) {    
     console.log('setter is true')   
     let flag =   Boolean(condition)
     console.log('flag is '+flag)  
    if (!condition && !this.hasView) { 
      console.log('flag is true')   
      this.viewContainer.createEmbeddedView(
        this.templateRef);
       let owner =  this.templateRef.elementRef
       //owner.nativeElement
      this.hasView = true;
    } else if (condition && this.hasView) {
      console.log('flag is false')   
      this.viewContainer.clear();
      this.hasView = false;
       
    }
  }
 
}


