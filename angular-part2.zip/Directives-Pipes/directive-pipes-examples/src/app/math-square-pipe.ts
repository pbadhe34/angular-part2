import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'squrepipe',
  standalone: true
})
export class SquarePipe implements PipeTransform {

  transform(value: number, ...args: unknown[]): number {
     let data =  value*value
     //return Math.pow(value, 2)
     return data

  }

}
