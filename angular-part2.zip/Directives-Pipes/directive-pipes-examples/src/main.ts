import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import { bootstrapApplication } from '@angular/platform-browser';
import { DirectivePage } from './app/directive.component';
import { PipeAppComponent } from './app/pipe-app/pipe-app.component';

if (environment.production) {
  enableProdMode();
}

/* platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.log(err)); */

 // bootstrapApplication(DirectivePage)
  bootstrapApplication(PipeAppComponent)
  .catch((err) => console.error(err));
